$(document).ready(function(){
  //Date Pickers
  $('.input-group').datepicker({
    autoclose: true,
    todayHighlight: true
  });
});
