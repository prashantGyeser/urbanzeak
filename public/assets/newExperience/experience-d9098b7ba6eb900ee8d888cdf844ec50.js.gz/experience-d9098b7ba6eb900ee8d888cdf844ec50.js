$(document).ready(function(){

    /*
    $('#new_experience_image').fileupload({
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress .bar').css(
                'width',
                progress + '%'
            );
        }
    });

    $(function(){
        $('select').selectric();
    });
    */
    //$('#schedule_calendar').multiDatesPicker();

    $(function() {
        $( "#schedule_calendar" ).multiDatesPicker();
      });



    // Change this to the location of your server-side upload handler:
    /*
    var url = '/images/create_header';

    $('#fileupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            $.each(data.result.files, function (index, file) {
                $('<p/>').text(file.name).appendTo('#files');
            });
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
    */
})

;
